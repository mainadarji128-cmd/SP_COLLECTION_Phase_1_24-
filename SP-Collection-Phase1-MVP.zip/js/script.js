// Simple geo-location greeting simulation
window.onload = function() {
    var greeting = document.getElementById('greeting');
    if(navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            // Simple demo: detect region based on latitude
            var lat = position.coords.latitude;
            if(lat > 0) greeting.innerText = 'Namaste! Welcome to SP Collection.';
            else greeting.innerText = 'Hello! Welcome to SP Collection.';
        }, function() {
            greeting.innerText = 'Hello! Welcome to SP Collection.';
        });
    } else {
        greeting.innerText = 'Hello! Welcome to SP Collection.';
    }
}
